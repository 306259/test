package myLinkedList;

import java.util.LinkedList;

public class MyLinkedListTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		LinkedList a = new LinkedList(); 
		

	}

}
